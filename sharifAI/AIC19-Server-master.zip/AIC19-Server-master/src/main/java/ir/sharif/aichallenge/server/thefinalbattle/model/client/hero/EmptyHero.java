package ir.sharif.aichallenge.server.thefinalbattle.model.client.hero;

import lombok.AllArgsConstructor;

@AllArgsConstructor
public class EmptyHero {
    private int id;
    private String type;
}
