package ir.sharif.aichallenge.server.thefinalbattle.model.graphic;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@AllArgsConstructor
public class RespawnedHero {
    int id;
    int row;
    int column;
}
