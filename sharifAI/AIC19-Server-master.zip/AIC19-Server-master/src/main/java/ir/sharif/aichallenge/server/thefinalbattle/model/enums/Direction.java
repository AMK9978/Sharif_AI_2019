package ir.sharif.aichallenge.server.thefinalbattle.model.enums;

public enum Direction {
	UP, DOWN, LEFT, RIGHT
}
