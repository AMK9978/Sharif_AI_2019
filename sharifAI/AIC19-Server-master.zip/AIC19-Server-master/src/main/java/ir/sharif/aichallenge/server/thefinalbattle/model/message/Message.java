package ir.sharif.aichallenge.server.thefinalbattle.model.message;

import lombok.*;

@Data
//@Builder
//@AllArgsConstructor
@NoArgsConstructor
@Setter
@Getter

public class Message {
}
