package ir.sharif.aichallenge.server.thefinalbattle.model.client;

import lombok.*;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class ClientMap {
    private ClientCell[][] cells;
}
