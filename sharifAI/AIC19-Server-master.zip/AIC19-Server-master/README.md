# AI Challenge 2019 - Server

## setup instructios

It is recomended to use Intellij IDEA (JetBrains)

You can run the program by downloading the server.jar file and using the following instruction:

```java -jar server.jar```

By using the option ```--view``` as shown below, file view.html will be created to help observing the game:

```java -jar server.jar --view```

By using the option ```--extra``` as shown below, you can increase the timeout:

```java -jar server.jar --extra=200``` or ```java -jar server.jar --extra:200```
