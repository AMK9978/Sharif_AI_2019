# AI Challenge 2019 Java Client
## Setup instructions

It is recommended to use IntelliJ IDEA(JetBtains):

```
Import directory you want to save and run the code
Then just run main function in Main.java
```





