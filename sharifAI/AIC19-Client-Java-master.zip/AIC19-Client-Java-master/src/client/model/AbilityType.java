package client.model;

public enum AbilityType {
    DEFENSIVE, DODGE, OFFENSIVE
}
