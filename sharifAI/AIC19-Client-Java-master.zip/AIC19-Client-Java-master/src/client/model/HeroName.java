package client.model;

public enum HeroName {
    SENTRY, BLASTER, HEALER, GUARDIAN
}
